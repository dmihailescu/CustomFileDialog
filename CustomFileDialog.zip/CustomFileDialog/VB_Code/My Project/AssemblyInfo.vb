﻿Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System
Imports System.Security.Permissions

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.
<Assembly: AssemblyTitle("FileDialogExtender")>
<Assembly: AssemblyDescription("Describes how to extend OpenFileDialog and SaveFileDialog.")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Decebal Mihailescu")>
<Assembly: AssemblyProduct("FileDialogExtender")>
<Assembly: AssemblyCopyright("Copyright © Decebal Mihailescu 2007-2012")> 
<Assembly: AssemblyTrademark("Decebal Mihailescu")>
<Assembly: AssemblyCulture("")>



' Setting ComVisible to false makes the types in this assembly not visible 
' to COM components.  If you need to access a type in this assembly from 
' COM, set the ComVisible attribute to true on that type.
<Assembly: ComVisible(False)>

' The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("4dc04980-30ff-4e13-a456-19a39f8195cf")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
<Assembly: AssemblyVersion("1.5.0.0")> 
<Assembly: AssemblyFileVersion("1.5.0.0")> 
