Imports Microsoft.VisualBasic
Imports System
Namespace FileDialogExtenders
	Partial Public Class FileDialogControlBase
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing



		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me.SuspendLayout()
			' 
			' FileDialogControlBase
			' 
			Me.Name = "FileDialogControlBase"
			Me.Size = New System.Drawing.Size(555, 385)
			Me.ResumeLayout(False)

		End Sub

		#End Region


		'protected System.Windows.Forms.OpenFileDialog _dlgOpen;



	End Class
End Namespace