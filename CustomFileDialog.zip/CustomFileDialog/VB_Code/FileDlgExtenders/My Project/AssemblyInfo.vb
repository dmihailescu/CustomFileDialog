﻿Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Security.Permissions
' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.
<Assembly: AssemblyTitle("FileDlgExtenders")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany("Decebal Mihailescu")>
<Assembly: AssemblyProduct("FileDlgExtenders")>
<Assembly: AssemblyCopyright("Copyright © Decebal Mihailescu 2007-2015")>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>
<Assembly: System.CLSCompliant(True)>

' Setting ComVisible to false makes the types in this assembly not visible 
' to COM components.  If you need to access a type in this assembly from 
' COM, set the ComVisible attribute to true on that type.
<Assembly: ComVisible(False)>

' The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("40585994-610c-4cb6-9350-eeea069fa7d6")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Revision and Build Numbers 
' by using the '*' as shown below:
<Assembly: AssemblyVersion("1.5.0.0")> 
<Assembly: AssemblyFileVersion("1.5.0.0")> 
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1020:AvoidNamespacesWithFewTypes", Scope := "namespace", Target := "FileDialogExtenders")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2122:DoNotIndirectlyExposeMethodsWithLinkDemands", Scope := "member", Target := "FileDialogExtenders.FileDialogControlBase+DialogWrapper`1..ctor(FileDialogExtenders.FileDialogControlBase,System.Windows.Forms.IWin32Window)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2122:DoNotIndirectlyExposeMethodsWithLinkDemands", Scope := "member", Target := "FileDialogExtenders.FileDialogControlBase+DialogWrapper`1.AssignDummyWindow(System.Windows.Forms.IWin32Window):System.Void")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2122:DoNotIndirectlyExposeMethodsWithLinkDemands", Scope := "member", Target := "FileDialogExtenders.FileDialogControlBase+DialogWrapper`1..ctor(FileDialogExtenders.FileDialogControlBase)")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2122:DoNotIndirectlyExposeMethodsWithLinkDemands", Scope := "member", Target := "FileDialogExtenders.FileDialogControlBase+DialogWrapper`1.AssignDummyWindow():System.Void")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1304:SpecifyCultureInfo", Scope := "member", Target := "FileDialogExtenders.FileDialogControlBase+DialogWrapper`1.FileDialogEnumWindowCallBack(System.IntPtr,System.Int32):System.Boolean", MessageId := "System.String.ToLower")>
<Assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope := "member", Target := "FileDialogExtenders.FileDialogControlBase+DialogWrapper`1.WndProc(System.Windows.Forms.Message&):System.Void")>

